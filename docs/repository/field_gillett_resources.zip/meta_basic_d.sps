*******************************************************************.
*   Field, A. & Gillett, R. (2009).   "How To Do Meta-Analysis".
*   British Journal of Mathematical and Statistical Psychology.
*******************************************************************.
set printback=none.
dataset name original.
cd  "%HOMEDRIVE%\%HOMEPATH%\My Documents\Meta-Analysis".   
matrix.
get d /variables = d.
get n1/variables = n1.
get n2/variables = n2.
compute n = 2*((n1&*n2)&/(n1+n2)).
compute k = nrow(d).
compute v = (n1+n2)&/(n1&*n2) + d&*d&/(2*(n1+n2)).
compute w = 1/v.
compute sw = csum(w).
compute c = sw - t(w)*w/sw.
compute q = t(w)*d&**2 - (t(w)*d)**2/sw.
compute tau = mmax({0, (q-k+1)/c}).
compute vt = v + tau.
compute wt = 1/vt.
compute swt = csum(wt).
compute qe = t(wt)*d&**2 - (t(wt)*d)**2/swt.

print /title = "**********   META-ANALYSIS OF STANDARDISED DIFFERENCES BETWEEN MEANS:  d   **********".
print {k}/clabels=k/format='f9.0'/title = "NUMBER OF STUDIES".

compute mean = {t(w)*d/sw; t(wt)*d/swt}.
compute sem = {sqrt(1/sw); sqrt(1/swt)}.
compute ci = {mean - 1.96*sem, mean + 1.96*sem}.
compute zscore = abs(mean&/sem).
compute pz = 2*(1 - cdfnorm(zscore)).
compute sed = {sqrt(v), sqrt(vt)}.
compute fsn = (t(d)*sqrt(n/2))**2/2.706 - k.
compute vtilde = {v - 1/sw, vt - 1/swt}.
compute u = make(k,1,1).
compute dstar = (d*{1,1} - u*t(mean))&/sqrt(vtilde).

print /title = "**********   FIXED-EFFECTS MODEL   **********".
print {mean(1), ci(1,1), ci(1,2), sem(1), zscore(1), pz(1), k}/clabels='Mean d', 'Lower d', 'Upper d', 'Std Err', z, p, k/format='f9.3'/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {q, k-1, 1-chicdf({q}, k-1)}/clabels=Chi2, df,p/format='f9.3'/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   RANDOM-EFFECTS MODEL   **********".
print {mean(2), ci(2,1), ci(2,2), sem(2), zscore(2), pz(2), k}/clabels='Mean d', 'Lower d', 'Upper d', 'Std Err', z, p, k/format='f9.3'/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {tau}/clabels=Tau/format=f9.4 /title = "Estimated Variance in Population Effect Size".
print {qe, k-1, 1-chicdf({qe}, k-1)}/clabels=Chi2, df,p/format='f9.3'/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   PUBLICATION BIAS DIAGNOSTIC INDICATORS   **********".
print fsn /format='f9.0'/title 'Rosenthal Fail-Safe N'.
save {d, v, dstar, sed, n} /outfile = 'Pub_Bias_Data.sav' /variables = d, v, dstar1, dstar2, sed1, sed2, n. 
end matrix.

get file = 'Pub_Bias_Data.sav'.
dataset name pubbias. 
dataset activate pubbias. 

formats d dstar1 dstar2 sed1 sed2 (f8.3) n (F8.0).
variable labels
d 'Effect size d'
dstar1 'Effect Size d (Standardised Across Studies)'
dstar2 'Effect Size d (Standardised Across Studies)'
sed1 'Standard Error of d'
sed2 'Standard Error of d'
n 'Sample Size'.

Title 'Funnel Plot  (Fixed-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=d WITH sed1
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Fixed-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Fixed-Effects Model)'.
NONPAR CORR
  /VARIABLES=dstar1 sed1
  /PRINT=KENDALL TWOTAIL NOSIG.

Title 'Funnel Plot  (Random-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=d WITH sed2
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Random-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Random-Effects Model)'.
NONPAR CORR
  /VARIABLES=dstar2 sed2
  /PRINT=KENDALL TWOTAIL NOSIG.

dataset activate original window=asis.
dataset close pubbias. 

*insert  file="Launch_Pub_Bias_d.sps".
