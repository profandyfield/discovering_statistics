*******************************************************************.
*   Field, A. & Gillett, R. (2009).   "How To Do Meta-Analysis".
*   British Journal of Mathematical and Statistical Psychology.
*******************************************************************.
set printback=none.
dataset name original.
cd  "%HOMEDRIVE%%HOMEPATH%\My Documents\Meta-Analysis".
matrix.
* input variables.
get p1 /variables = p1.
get p2 /variables = p2.
get n1 /variables = n1.
get n2 /variables = n2.
compute n = 2*((n1&*n2)&/(n1+n2)).
compute k = nrow(p1).
compute h = p1 - p2.
compute v = p1&*(1 - p1)&/n1 + p2&*(1 - p2)&/n2.
compute w = 1/v.
compute sw = csum(w).
compute c = sw - t(w)*w/sw.
compute q = t(w)*h&**2 - (t(w)*h)**2/sw.
compute tau = mmax({0, (q-k+1)/c}).
compute vt = v + tau.
compute wt = 1/vt.
compute swt = csum(wt).
compute qe = t(wt)*h&**2 - (t(wt)*h)**2/swt.

print /title = "**********   META-ANALYSIS OF DIFFERENCE BETWEEN PROPORTIONS   **********".
print /title = "**********   USING EFFECT-SIZE MEASURE:  D = p1 - p2           **********".
print {k}/clabels=k/format=f9.0/title = "NUMBER OF STUDIES".

* obtain weighted means for F-E and R-E models. 
compute mean = {t(w)*h/sw; t(wt)*h/swt}.
* calculate standard errors and confidence intervals for means. 
compute sem = {sqrt(1/sw); sqrt(1/swt)}.
compute ci = {mean - 1.96*sem, mean + 1.96*sem}.
compute zscore = abs(mean&/sem).
compute pz = 2*(1 - cdfnorm(zscore)).
* calculate fsn (Rosenthal Fail-Safe N).
compute seh = {sqrt(v), sqrt(vt)}.
compute fsn = (t(h)*(1/sqrt(v(:,1))))**2/2.706 - k.
* standardise h values across studies for F-E and R-E models ( Begg & Mazumdar, 1994).
compute vtilde = {v - 1/sw, vt - 1/swt}.
compute u = make(k,1,1).
compute hstar = (h*{1,1} - u*t(mean))&/sqrt(vtilde).

print /title = "**********   FIXED-EFFECTS MODEL   **********".
print {mean(1), ci(1,1), ci(1,2), zscore(1), pz(1), k}/clabels='Mean D', 'Lower D', 'Upper D', z, p, k/format=f9.3/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {q, k-1, 1-chicdf({q}, k-1)}/clabels=Chi2, df,p/format=f9.3/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   RANDOM-EFFECTS MODEL   **********".
print {mean(2), ci(2,1), ci(2,2), zscore(2), pz(2), k}/clabels='Mean D', 'Lower D', 'Upper D', z, p, k/format=f9.3/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {tau}/clabels=Tau/format=f9.4 /title = "Estimated Variance in Population  D = p1 - p2  Values".
print {qe, k-1, 1-chicdf({qe}, k-1)}/clabels=Chi2, df,p/format=f9.3/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   PUBLICATION BIAS DIAGNOSTIC INDICATORS   **********".
print fsn /format=f9.0/title 'Rosenthal Fail-Safe N'.
save {h, v, hstar, seh, n} /outfile = 'Pub_Bias_Data.sav' /variables = D, v, Dstar1, Dstar2, seD1, seD2, n. 
end matrix.

get file = 'Pub_Bias_Data.sav'.
dataset name pubbias. 
dataset activate pubbias. 

formats D Dstar1 Dstar2 seD1 seD2 (f8.3) n (F8.0).
variable labels
D 'Effect Size D = p1 - p2'
Dstar1 'Effect Size D (Standardised Across Studies)'
Dstar2 'Effect Size D (Standardised Across Studies)'
seD1 'Standard Error of D = p1 - p2'
seD2 'Standard Error of D = p1 - p2'
n 'Sample Size'.

Title 'Funnel Plot  (Fixed-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=D WITH seD1
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Fixed-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Fixed-Effects Model)'.
NONPAR CORR
  /VARIABLES=Dstar1 seD1
  /PRINT=KENDALL TWOTAIL NOSIG.

Title 'Funnel Plot  (Random-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=D WITH seD2
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Random-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Random-Effects Model)'.
NONPAR CORR
  /VARIABLES=Dstar2 seD2
  /PRINT=KENDALL TWOTAIL NOSIG.

dataset activate original window=asis.
dataset close pubbias. 

matrix.
* input variables.
get p1 /variables = p1.
get p2 /variables = p2.
get n1 /variables = n1.
get n2 /variables = n2.
compute n = 2*((n1&*n2)&/(n1+n2)).
compute k = nrow(p1).
* calculate Cohen's (1988) arcsin transformation of  p1 - p2.
compute h = 2*arsin(sqrt(p1)) - 2*arsin(sqrt(p2)).
* h has variance = 1/n1 + 1/n2.
compute v = 1/n1 + 1/n2.
compute w = 1/v.
compute sw = csum(w).
compute c = sw - t(w)*w/sw.
compute q = t(w)*h&**2 - (t(w)*h)**2/sw.
compute tau = mmax({0, (q-k+1)/c}).
compute vt = v + tau.
compute wt = 1/vt.
compute swt = csum(wt).
compute qe = t(wt)*h&**2 - (t(wt)*h)**2/swt.

print /title = "**********   META-ANALYSIS OF DIFFERENCE BETWEEN PROPORTIONS   **********".
print /title = "**********   USING EFFECT-SIZE MEASURE:  COHEN'S  h,   WHERE   **********".
print /title = "**********     h = 2*arcsin(sqrt(p1)) - 2*arcsin(sqrt(p2))     **********".
print {k}/clabels=k/format=f9.0/title = "NUMBER OF STUDIES".

* obtain weighted means for F-E and R-E models. 
compute mean = {t(w)*h/sw; t(wt)*h/swt}.
* calculate standard errors and confidence intervals for means. 
compute sem = {sqrt(1/sw); sqrt(1/swt)}.
compute ci = {mean - 1.96*sem, mean + 1.96*sem}.
compute zscore = abs(mean&/sem).
compute pz = 2*(1 - cdfnorm(zscore)).
* calculate fsn (Rosenthal Fail-Safe N).
compute seh = {sqrt(v), sqrt(vt)}.
compute fsn = (t(h)*sqrt(n/2))**2/2.706 - k.
* standardise h values across studies for F-E and R-E models ( Begg & Mazumdar, 1994).
compute vtilde = {v - 1/sw, vt - 1/swt}.
compute u = make(k,1,1).
compute hstar = (h*{1,1} - u*t(mean))&/sqrt(vtilde).

print /title = "**********   FIXED-EFFECTS MODEL   **********".
print {mean(1), ci(1,1), ci(1,2), zscore(1), pz(1), k}/clabels='Mean h', 'Lower h', 'Upper h', z, p, k/format=f9.3/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {q, k-1, 1-chicdf({q}, k-1)}/clabels=Chi2, df,p/format=f9.3/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   RANDOM-EFFECTS MODEL   **********".
print {mean(2), ci(2,1), ci(2,2), zscore(2), pz(2), k}/clabels='Mean h', 'Lower h', 'Upper h', z, p, k/format=f9.3/title='MEAN EFFECT SIZE, LOWER & UPPER 95% CONFIDENCE BOUNDS, AND Z-TEST '.
print {tau}/clabels=Tau/format=f9.4 /title = "Estimated Variance in Population  h  Values".
print {qe, k-1, 1-chicdf({qe}, k-1)}/clabels=Chi2, df,p/format=f9.3/title = "HOMOGENEITY TEST:  Q STATISTIC  (Goodness of Fit)".

print /title = "**********   PUBLICATION BIAS DIAGNOSTIC INDICATORS   **********".
print fsn /format=f9.0/title 'Rosenthal Fail-Safe N'.
get Dvars /file = 'Pub_Bias_Data.sav' /variables = D, v, Dstar1, Dstar2, seD1, seD2. 
save {Dvars, h, v, hstar, seh, n} /outfile = 'Pub_Bias_Data.sav' /variables = D, v, Dstar1, Dstar2, seD1, seD2, h, vh, hstar1, hstar2, seh1, seh2, n. 
end matrix.

get file = 'Pub_Bias_Data.sav'.
dataset name pubbias. 
dataset activate pubbias. 

formats h hstar1 hstar2 seh1 seh2 (f8.3) n (F8.0).
variable labels
h 'Effect Size h'
hstar1 'Effect Size h (Standardised Across Studies)'
hstar2 'Effect Size h (Standardised Across Studies)'
seh1 'Standard Error of h'
seh2 'Standard Error of h'
n 'Sample Size'.

Title 'Funnel Plot  (Fixed-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=h WITH seh1
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Fixed-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Fixed-Effects Model)'.
NONPAR CORR
  /VARIABLES=hstar1 seh1
  /PRINT=KENDALL TWOTAIL NOSIG.

Title 'Funnel Plot  (Random-Effects Model)'.
GRAPH
  /SCATTERPLOT(BIVAR)=h WITH seh2
  /TITLE='Funnel Plot of Effect Size vs. Standard Error  (Random-Effects Model)'.

Title 'Begg & Mazumdar Rank Correlation  (Random-Effects Model)'.
NONPAR CORR
  /VARIABLES=hstar2 seh2
  /PRINT=KENDALL TWOTAIL NOSIG.

dataset activate original window=asis.
dataset close pubbias. 

*insert  file="Launch_Pub_Bias_D_h.sps".




