*******************************************************************.
*   Field, A. & Gillett, R. (2009).   "How To Do Meta-Analysis".
*   British Journal of Mathematical and Statistical Psychology.
*******************************************************************.
cd  "%HOMEDRIVE%%HOMEPATH%\My Documents\Meta-Analysis".   
insert  file="Meta_Mod_d.sps".   
Moderator_d   d=d  n1=n1  n2=n2  conmods=( )  catmods=(age  source).