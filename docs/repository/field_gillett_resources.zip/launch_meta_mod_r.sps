*******************************************************************.
*   Field, A. & Gillett, R. (2009).   "How To Do Meta-Analysis".
*   British Journal of Mathematical and Statistical Psychology.
*******************************************************************.
cd  "%HOMEDRIVE%%HOMEPATH%\My Documents\Meta-Analysis".   
insert  file="Meta_Mod_r.sps".   
Moderator_r  r=r  n=n  conmods=( )  catmods=(genexp). 
