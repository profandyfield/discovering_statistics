####################################################################
#                                                                  #
#    Field, A. & Gillett, R. (2009).  "How To Do Meta-Analysis"    #
#    British Journal of Mathematical and Statistical Psychology    #
#                                                                  #
#           With acknowledgments to Vevea & Woods(2005)            #
####################################################################

options(warn=-1)
require(foreign)
fp <- paste(Sys.getenv("R_USER"),"Meta-Analysis","Pub_Bias_Data.sav",sep="\\")
mydata <- read.spss(file=fp)
myT <- mydata$zr
n <- length(myT)
v <- mydata$v
npred <- 0
X <- matrix(c(rep(1,times=n)),n,npred+1,byrow=T)

if(length(v) != n) stop("Number of conditional variances must equal number of effects.")
for(i in 1:length(v)) if(v[i] <0) stop("Variances must be non-negative.")
s <- sqrt(v)

if(dim(X)[1] != n) stop("Number of rows in predictor matrix must match number of effects.")

#
# Set p = number of predictors
p <- dim(X)[2]-1

#
# In this example, cutpoints and weights are for the condition denoted 
# �severe two-tailed selection� in the paper.

# Enter cutpoints for p-value intervals
a <- c(.005,.010,.050,.100,.250,.350,.500,.650,.750,.900,.950,.990,.995,1.00)
#
# Enter fixed weight function
w1 <- matrix(
   c(1.0,.99,.95,.90,.80,.75,.65,.60,.55,.50,.50,.50,.50,.50),
   ncol=1)
w2 <- matrix(
   c(1.0,.99,.90,.75,.60,.50,.40,.35,.30,.25,.10,.10,.10,.10),
   ncol=1)
w3 <- matrix(
   c(1.0,.99,.95,.90,.80,.75,.60,.60,.75,.80,.90,.95,.99,1.0),
   ncol=1)
w4 <- matrix(
   c(1.0,.99,.90,.75,.60,.50,.25,.25,.50,.60,.75,.90,.99,1.0),
   ncol=1)

#
# Do not modify below this point
#
# Set k = number of intervals
k <- length(a)

if(length(w1) != k) stop("Number of weights must match number of intervals")
if(length(w2) != k) stop("Number of weights must match number of intervals")
if(length(w3) != k) stop("Number of weights must match number of intervals")
if(length(w4) != k) stop("Number of weights must match number of intervals")

#
# Do weighted least squares. (Don�t do this at home; the algorithm is unstable
# for general regression problems, but it�s easy and unlikely to cause problems
# in this context.)
varmat <- diag(v)
tmat <- matrix(myT,nrow=n)
beta <- solve( t(X)%*%solve(varmat)%*%X)%*%t(X)%*%solve(varmat)%*%tmat

#
# Set starting value for parameter vector
params <- beta

#
# Here we set up Bij and bij
#
# First, we need predicted values
xb <- X%*%beta
sig <- sqrt(v)

#
# Now bij = -si probit(aj)
b <- matrix(rep(0,n*(k-1)),nrow=n,ncol=k-1)
for(i in 1:n) 
   for(j in 1:k-1) 
      b[i,j] <- -s[i] * qnorm(a[j])

#
# And now Bij (Equation 5)
Bij <- function(params) {
   B <- matrix(rep(0,n*k),nrow=n,ncol=k)
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   for(i in 1:n)
      for(j in 1:k) {
         if(j==1) B[i,j] <- 1.0 - pnorm( (b[i,1]-xb[i]) / sig[i])
         else if(j<k) B[i,j] <- pnorm( (b[i,j-1]-xb[i]) / sig[i]) - pnorm( (b[i,j]-xb[i]) / sig[i])
         else B[i,j] <- pnorm( (b[i,k-1]-xb[i]) / sig[i])
      }
   return(B)
}

#
# Unadjusted likelihood function
like1 <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   -2*(-1/2 * (sum( (myT-xb)^2/v ) + sum(log(v)))   )
}

#
# adjusted likelihood function Moderate One-Tailed Selection (Equation 6)
like2 <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   ll <- -1/2 * (sum( (myT-xb)^2/v ) + sum(log(v)))   
   B <- Bij(params)
   Bw <- B%*%w1
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# adjusted likelihood function Severe One-Tailed Selection (Equation 6)
like3 <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   ll <- -1/2 * (sum( (myT-xb)^2/v ) + sum(log(v)))   
   B <- Bij(params)
   Bw <- B%*%w2
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# adjusted likelihood function Moderate Two-Tailed Selection (Equation 6)
like4 <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   ll <- -1/2 * (sum( (myT-xb)^2/v ) + sum(log(v)))   
   B <- Bij(params)
   Bw <- B%*%w3
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# adjusted likelihood function Severe Two-Tailed Selection (Equation 6)
like5 <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   ll <- -1/2 * (sum( (myT-xb)^2/v ) + sum(log(v)))   
   B <- Bij(params)
   Bw <- B%*%w4
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# Second derivatives, unadjusted model 
fese <- function(params) {
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   hessian <- matrix(rep(0,(p+1)*(p+1)),p+1,p+1)
   for(i in 1:n) {
      for(j in 1:(p+1))
         for(m in 1:(p+1)) 
            hessian[j,m] <- hessian[j,m] - X[i,j]*X[i,m]/v[i]
   }
   temp <- solve(hessian)
   retval <- rep(0,(p+1))
   for(i in 1:(p+1)) retval[i] <- sqrt(-temp[i,i])
   return(retval)
}

# Fit unweighted model by maximum likelihood
fe1 <- nlminb(objective=like1, start=params)
#se1 <- fese(fe1$par)
fe1$par[2] <- (exp(2*fe1$par[1])-1)/(exp(2*fe1$par[1])+1)

#
# Fit adjusted model Moderate one-Tailed Selection
fe2 <- nlminb(objective=like2, start=fe1$par)
fe2$par[2] <- (exp(2*fe2$par[1])-1)/(exp(2*fe2$par[1])+1)

#
# Fit adjusted model Severe one-Tailed Selection
fe3 <- nlminb(objective=like3, start=fe1$par)
fe3$par[2] <- (exp(2*fe3$par[1])-1)/(exp(2*fe3$par[1])+1)

#
# Fit adjusted model Moderate Two-Tailed Selection
fe4 <- nlminb(objective=like4, start=fe1$par)
fe4$par[2] <- (exp(2*fe4$par[1])-1)/(exp(2*fe4$par[1])+1)

#
# Fit adjusted model Severe Two-Tailed Selection
fe5 <- nlminb(objective=like5, start=fe1$par)
fe5$par[2] <- (exp(2*fe5$par[1])-1)/(exp(2*fe5$par[1])+1)

#
# Also, set variance component to balanced method of moments start
rss <- sum((myT-X%*%beta)^2)
vc <- rss/(n-p-1) - mean(v)
if (vc < 0.0) vc <- 0.0

#
# Set starting value for parameter vector
params <- c(beta,vc)

#
# Here we set up Bij and bij
#
# First, we need predicted values
xb <- X%*%beta
sig <- sqrt(v + vc)

#
# Now bij = -si probit(aj)
b <- matrix(rep(0,n*(k-1)),nrow=n,ncol=k-1)
for(i in 1:n) 
   for(j in 1:k-1) 
      b[i,j] <- -s[i] * qnorm(a[j])

#
# And now Bij (Equation 5)
Bij <- function(params) {
   B <- matrix(rep(0,n*k),nrow=n,ncol=k)
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   for(i in 1:n)
      for(j in 1:k) {
         if(j==1) B[i,j] <- 1.0 - pnorm( (b[i,1]-xb[i]) / sig[i])
         else if(j<k) B[i,j] <- pnorm( (b[i,j-1]-xb[i]) / sig[i]) - pnorm( (b[i,j]-xb[i]) / sig[i])
         else B[i,j] <- pnorm( (b[i,k-1]-xb[i]) / sig[i])
      }
   return(B)
}

#
# Unadjusted likelihood function
like1 <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   -2*(-1/2 * (sum( (myT-xb)^2/vall ) + sum(log(vall)))   )
}

#
# Adjusted likelihood function Moderate One-Tailed Selection (Equation 6)
like2 <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   ll <- -1/2 * (sum( (myT-xb)^2/vall ) + sum(log(vall)))   
   B <- Bij(params)
   Bw <- B%*%w1
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# Adjusted likelihood function Severe One-Tailed Selection (Equation 6)
like3 <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   ll <- -1/2 * (sum( (myT-xb)^2/vall ) + sum(log(vall)))   
   B <- Bij(params)
   Bw <- B%*%w2
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# Adjusted likelihood function Moderate two-Tailed Selection (Equation 6)
like4 <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   ll <- -1/2 * (sum( (myT-xb)^2/vall ) + sum(log(vall)))   
   B <- Bij(params)
   Bw <- B%*%w3
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# Adjusted likelihood function Severe Two-Tailed Selection (Equation 6)
like5 <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   ll <- -1/2 * (sum( (myT-xb)^2/vall ) + sum(log(vall)))   
   B <- Bij(params)
   Bw <- B%*%w4
   ll <- ll - sum(log(Bw))
   return(-2*ll)
}

#
# Second derivatives, unadjusted model 
rese <- function(params) {
   vc <- params[p+2]
   beta <- matrix(params[1:(p+1)],ncol=1)
   xb <- X%*%beta
   vall <- v+vc
   hessian <- matrix(rep(0,(p+2)*(p+2)),p+2,p+2)
   for(i in 1:n) {
      for(j in 1:(p+1))
         for(m in 1:(p+1)) 
            hessian[j,m] <- hessian[j,m] - X[i,j]*X[i,m]/vall[i]
      for(j in 1:(p+1)) {
         hessian[j,p+2] <- hessian[j,p+2] - (myT[i]-xb[i])/vall[i]/vall[i]
         hessian[p+2,j] <- hessian[p+2,j] - (myT[i]-xb[i])/vall[i]/vall[i]
      }
      hessian[p+2,p+2] <- hessian[p+2,p+2] + 1/vall[i]/vall[i]/2 - 
                          (myT[i]-xb[i])*(myT[i]-xb[i])/vall[i]/vall[i]/vall[i]
   }
   temp <- solve(hessian)
   retval <- rep(0,(p+2))
   for(i in 1:(p+2)) retval[i] <- sqrt(-temp[i,i])
   return(retval)
}

#
# Fit unadjusted model by maximum likelihood
re1 <- nlminb(objective=like1, start=params,lower=c(rep(-Inf,p+1),0.0))
#se1 <- rese(re1$par)
re1$par[3] <- (exp(2*re1$par[1])-1)/(exp(2*re1$par[1])+1)

#
# Fit adjusted model Moderate one-Tailed Selection
re2 <- nlminb(objective=like2, start=re1$par,lower=c(rep(-Inf,p+1),0.0))
re2$par[3] <- (exp(2*re2$par[1])-1)/(exp(2*re2$par[1])+1)

#
# Fit adjusted model Severe one-Tailed Selection
re3 <- nlminb(objective=like3, start=re1$par,lower=c(rep(-Inf,p+1),0.0))
re3$par[3] <- (exp(2*re3$par[1])-1)/(exp(2*re3$par[1])+1)

#
# Fit adjusted model Moderate Two-Tailed Selection
re4 <- nlminb(objective=like4, start=re1$par,lower=c(rep(-Inf,p+1),0.0))
re4$par[3] <- (exp(2*re4$par[1])-1)/(exp(2*re4$par[1])+1)

#
# Fit adjusted model Severe Two-Tailed Selection
re5 <- nlminb(objective=like5, start=re1$par,lower=c(rep(-Inf,p+1),0.0))
re5$par[3] <- (exp(2*re5$par[1])-1)/(exp(2*re5$par[1])+1)

unadjfe <- rbind(unadjfe1 <- fe1$par, unadjfe2 <- fese(fe1$par))
unadjfe[2,2]=NA
rownames(unadjfe) <- c("Parameter Estimates", "Standard errors                  ")
colnames(unadjfe) <- c("zr", "r")

unadjre <- rbind(unadjre1 <- re1$par, unadjre2 <- c(rese(re1$par),NA))
rownames(unadjre) <- c("Parameter Estimates", "Standard errors                  ")
colnames(unadjre) <- c("zr", "v", "r")

adjfe <- rbind(adj1 <- fe2$par, adj2 <- fe3$par, adj3 <- fe4$par, adj4 <- fe5$par)
rownames(adjfe) <- c("Moderate One-Tailed Selection    ", "Severe One-Tailed Selection", "Moderate Two-Tailed Selection", "Severe Two-Tailed Selection")
colnames(adjfe) <- c("zr", "r")

adjre <- rbind(adj1 <- re2$par, adj2 <- re3$par, adj3 <- re4$par, adj4 <- re5$par)
rownames(adjre) <- c("Moderate One-Tailed Selection    ", "Severe One-Tailed Selection", "Moderate Two-Tailed Selection", "Severe Two-Tailed Selection")
colnames(adjre) <- c("zr", "v", "r")

out1 <- paste("\n\n\n**********  SENSITIVITY OF EFFECT-SIZE ESTIMATES TO PUBLICATION BIAS  **********\n")
out1 <- paste(out1, "\n\n\EFFECT-SIZE PARAMETER:   Correlation  \n")
out1 <- paste(out1, "\nEFFECT-SIZE ESTIMATOR:   r   \n")     
out1 <- paste(out1, "\n\nFIXED-EFFECTS Publication Bias Model: Vevea & Woods (2005), Psychological Methods") 
out1 <- paste(out1, "\n\nUnadjusted Parameter Estimate\n")
out2 <- paste("\nAdjusted Parameter Estimate\n")
out3 <- paste("\n\nRANDOM-EFFECTS Publication Bias Model: Vevea & Woods (2005), Psychological Methods")
out3 <- paste(out3, "\nIn this model v estimates population effect-size variance\n")
out3 <- paste(out3, "\nUnadjusted Parameter Estimates\n")
out4 <- paste("\nAdjusted Parameter Estimates\n")

cat(out1); unadjfe; cat(out2); adjfe; cat(out3); unadjre; cat(out4); adjre; 




