dataset name original.
cd  "C:\Program Files\R".
host command=['dir /a:d /b /o:-n R-* > "%HOMEDRIVE%%HOMEPATH%\My Documents\Meta-Analysis\rvn.txt" '].
cd  "%HOMEDRIVE%%HOMEPATH%\My Documents\Meta-Analysis".   
get data /type=TXT /file='rvn.txt'  /arrangement=fixed /fixcase=1 /firstcase=1 /importcase=first 1 /variables=ver_no 2-6 a5.
dataset name rvn. 
dataset activate rvn. 
string s4 s5 (a79).
compute s4='"C:\Program Files\R\R-2.7.2\bin\Rterm.exe" --vanilla --slave -q -f Pub_Bias_r.R'. 
compute s5=replace(s4, "2.7.2",ver_no).
write outfile="rfp.bat" / '@echo off' / s5 (a79).
execute.
dataset activate original window=asis.
dataset close rvn. 
host command=['rfp'].
